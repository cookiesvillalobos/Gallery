#include <iostream>
#include "Networking/Server.h"

int main() {
    std::cout << "Hello, World!" << std::endl;
    Server::start();

    return 0;
}