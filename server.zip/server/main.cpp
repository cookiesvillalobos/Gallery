#include <iostream>
#include "Networking/Server.h"
#include "Networking/NetPackage.h"

int main() {
    std::cout << "Hello, World!" << std::endl;
    Server::start();

    return 0;
}