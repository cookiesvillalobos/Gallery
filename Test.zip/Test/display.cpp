#include "display.h"
#include "ui_display.h"

#include <QGraphicsView>
#include <QGraphicsPixmapItem>
#include <QPushButton>
#include <QMovie>
#include <QLabel>
#include <QPropertyAnimation>
#include <QtDebug>
#include <iostream>
#include <QTimer>
#include <QTime>
#include <QString>
#include "netpackage.h"


Display::Display(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Display)
{
    ui->setupUi(this);

    this->setAttribute(Qt::WA_DeleteOnClose);

}

Display::~Display()
{
    delete ui;
}


string Display::splitCommand(string *command){
    string subCommand = command->substr(0, command->find("."));
    command->erase(0, command->find(".")+1);
    return subCommand;
}

void Display::runCommands(GenericLinkedList<string> *commands){
    for(int i=0; i<commands->getLength();i++){
        string command = commands->get(i)->getData();

        if(command=="finish")active = false;
        string action = splitCommand(&command);

        if (action=="setStats"){
            std::cout << "updateImage" << std::endl;
            active = false;
        }
        if (action=="getImage"){
            std::cout << "getImage" << std::endl;
            active = false;
        }
        if (action=="deleteImage"){
            std::cout << "deleteImage" << std::endl;
            active = false;
        }

    }
}

void Display::gameLoop(){
    while(active){
        QEventLoop loop;
        QTimer::singleShot(1300,&loop,SLOT(quit()));
        loop.exec();

    }
}

void Display::showEvent(QShowEvent *ev){
    QMainWindow::showEvent(ev);
    //QTimer::singleShot(500, this, SLOT(restart()));
    return;
}


void Display::on_select_button_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this, tr("Choose"),"",tr("Images (*.png, *.jpg, *.jpeg)"));

    if (QString::compare(filename, QString()) != 0){
        QImage image;
        bool valid = image.load(filename);

        if(valid){
            ui->lbl_image->setPixmap(QPixmap::fromImage(image));
        }
    }

}

void Display::on_pushButton_clicked(){
    QString name = (ui->name_info->toPlainText());
    QString author = ui->author_info->toPlainText();
    QString year = ui->year_info->toPlainText();
    QString descrip = ui->descrip_info->toPlainText();

    ui->name_info->clear();
    ui->author_info->clear();
    ui->year_info->clear();
    ui->descrip_info->clear();

    string info[5]={name.toStdString(),author.toStdString(),year.toStdString(),descrip.toStdString(),"image"};
    Connector::get("upd",info);

}

void Display::on_back_button_clicked()
{
    MainWindow *window = new MainWindow();
    window->show();
    this->hide();

}
