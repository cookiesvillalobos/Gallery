#include "connector.h"
#include "string"
#include <sstream>

Connector::Connector()
{
}

GenericLinkedList<std::string>* convertStringToLL(std::string data){
    std::stringstream ss(data);
    GenericLinkedList<std::string>* list = new GenericLinkedList<std::string>;

    while( ss.good() )
    {
        std::string substr;
        getline( ss, substr, ',' );
        list->add(substr);
    }
    return list;
}

int convertCommandToInt(std::string data) {
    enum commands {
        upd = 0,
        get,
        del,
        restart,
    };
    if (data == "upd") {
        return upd;
    }
    if (data == "get") {
        return get;
    }
    if (data == "del") {
        return del;
    }
    if (data == "restart"){
        return restart;
    }
    return -1;
}

GenericLinkedList<std::string>* Connector::get(std::string request){
        int sock = socket(AF_INET, SOCK_STREAM, 0);
        if (sock == -1)
        {
        }
        int port = 8888;
        std::string ipAddress = "127.0.0.1";
        sockaddr_in hint;
        hint.sin_family = AF_INET;
        hint.sin_port = htons(port);
        inet_pton(AF_INET, ipAddress.c_str(), &hint.sin_addr);

        int connectRes = connect(sock, (sockaddr*)&hint, sizeof(hint));

        char buf[4096];
        NetPackage netpack = NetPackage();
        netpack.setFrom("Client");
        int requestStr = convertCommandToInt(request);
        std::cout << requestStr << std::endl;
        switch(requestStr){
        case 0:
        {netpack.setCommand("upd");
            std::string finalMessage = netpack.getJSONPackage();
            std::cout << finalMessage << std::endl;
            send(sock, finalMessage.c_str(), strlen(finalMessage.c_str()), 0);
            memset(buf, 0, 4096);
            int bytesReceived = recv(sock, buf, 4096, 0);
            std::string preResponse =  std::string(buf, bytesReceived);

            std::cout << "Llego " << preResponse << std::endl;

            rapidjson::Document doc = NetPackage::convertToRJ_Document(preResponse);

            std::string response = doc["NetPackage"]["data"].GetString();

            std::cout << "Llego " << response << std::endl;

            GenericLinkedList<std::string>* list = convertStringToLL(response);

            close(sock);

            return list;


        }
            break;
        case 1:
        {
            netpack.setCommand("get");
            close(sock);
        }
            break;
        case 2:
        {netpack.setCommand("del");
            std::string test = "None";
            netpack.setData(test);
            std::string finalMessage = netpack.getJSONPackage();
            std::cout << finalMessage << std::endl;
            send(sock, finalMessage.c_str(), finalMessage.size(), 0);
            memset(buf, 0, 4096);
            int bytesReceived = recv(sock, buf, 4096, 0);
            std::string preResponse =  std::string(buf, bytesReceived);

            std::cout << "Llego " << preResponse << std::endl;

            rapidjson::Document doc = NetPackage::convertToRJ_Document(preResponse);

            std::string response = doc["NetPackage"]["data"].GetString();

            std::cout << "Llego " << response << std::endl;

            GenericLinkedList<std::string>* list = convertStringToLL(response);

            close(sock);

            return list;

        }
            break;
        case 3:
        {
            std::cout << "Llegue" << std::endl;
            netpack.setCommand("restart");
            std::string final = netpack.getJSONPackage();
            send(sock, final.c_str(), strlen(final.c_str()), 0);
            close(sock);
        }
            break;
        default:
            break;
        }

        //close(sock);
}

