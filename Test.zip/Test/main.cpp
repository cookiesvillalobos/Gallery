#include "mainwindow.h"
#include "display.h"
#include <QApplication>
#include "connector.h"
#include "genericlinkedlist.h"
#include "display.h"
#include "connector.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();

    //Connector::get("upd");
}
