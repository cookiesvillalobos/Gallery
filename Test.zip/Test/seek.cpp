#include "seek.h"
#include "ui_seek.h"

seek::seek(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::seek)
{
    ui->setupUi(this);

    this->setAttribute(Qt::WA_DeleteOnClose);
    loop();
}

seek::~seek()
{
    delete ui;
}

void seek::loop(){
}
