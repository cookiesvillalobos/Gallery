#ifndef SEEK_H
#define SEEK_H


#include <QMainWindow>
#include "genericlinkedlist.h"
#include "connector.h"

namespace Ui {
class seek;
}

class seek : public QMainWindow
{
    Q_OBJECT

public:
    explicit seek(QWidget *parent = 0);
    ~seek();
    void loop();

private:
    Ui::seek *ui;
};

#endif // SEEK_H
