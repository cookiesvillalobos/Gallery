#ifndef DISPLAY_H
#define DISPLAY_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QLabel>
#include <QList>
#include <QFileDialog>
#include "display.h"

#include "genericlinkedlist.h"
#include "connector.h"

using namespace std;

namespace Ui
{
class Display;
}

/**
 * @brief The Display class Where you can see or update or delete photos
 * from the gallery
 */
class Display : public QMainWindow
{
    Q_OBJECT

public:
    /**
     * @brief Display class constructor
     * @param parent
     */
    explicit Display(QWidget *parent = nullptr);

    /**
      *@brief Display class destructor
      */
    ~Display();


    /**
     * @brief splitCommand splits a subcommand out of a command string
     * @param command String
     * @return A subcommand
     */
    string splitCommand(string *command);

    /**
     * @brief runCommands Displays all the commands in a given list.
     * @param commands List holding the commands
     */
    void runCommands(GenericLinkedList<string> *commands);

    /**
     * @brief gameLoop Handles the main loop
     */
    void gameLoop();

    /**
     * @brief scene All the visual elements are inside this scene for display
     */
    QGraphicsScene *scene;

protected:
    /**
     * @brief showEvent Restarts the window every time is shown
     * @param ev Event signal
     */
    void showEvent(QShowEvent *ev);


private:
    /**
     * @brief ui Display Class
     * Used tp arrange the visual objects
     */
    Ui::Display *ui;

    /**
     * @brief view The scene is added to it for display purposes
     */
    QGraphicsView *view;

    /**
     * @brief active
     * Used to know if the action is still active
     */
    bool active;

    /**
     * @brief Image QLabel
     * Holds the image info of whats going on
     */
    QLabel *Image;

    /**
     * @brief infoLabels
     * Lists that contains all the information labels from the panel
     */
    QList<QLabel*> *infoLabels;

public slots:
    /**
     * @brief restart Slots function called when the window is shown
     * Restart the game flow
     */
    //void restart();

private slots:
    void on_select_button_clicked();
};

#endif // DISPLAY_H
